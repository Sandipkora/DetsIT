<?php

include "menu.php";
include "footer.php";
?>
			<!-- Sidebar wrapper end -->

			<!-- Page content start  -->
			<div class="page-content">
				
				<!-- Main container start -->
				<div class="main-container">

					
					<!-- Header start -->
				
					<!-- Header end -->

					<!-- Page header start -->
					<div class="page-header">

						<!-- Breadcrumb start -->
						<ol class="breadcrumb">
							<li class="breadcrumb-item">Review Assingment</li>
						</ol>
						<!-- Breadcrumb end -->

						<!-- App actions start -->
						<!-- App actions end -->

					</div>
					<!-- Page header end -->
					
					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							
							<div class="table-container">
								<div class="t-header">Basic Example</div>
								<div class="table-responsive">
									<table id="basicExample" class="table custom-table">
										<thead>
											<tr>
												<th>Student Name</th>
                                                <th>Subject</th>
												<th>Roll No.</th>
												<th>Registration No.</th>
												<th>Contact</th>
                                                <th>Email</th>
												<th>View<i class="icon-eye"></i></th>
												<th>Remark<i class="icon-edit"></i></th>
												
											</tr>
										</thead>
										<tbody>
											<tr>
                                                <td>Nabin Ghosal</td>
												<td>Data Structure</td>
												<td>90/INT/190023</td>
                                                <td>190024</td>
                                                <td>+9198745632</td>
                                                <td>Nabinghosal@gmail.com</td>
                                                <td><i class="icon-eye"></i></td>
												<td><i class="icon-edit"></i></td>
												
											</tr>
											<tr>
                                                <td>Algorithm</td>
												<td>Shrinka Basu</td>
												<td><a href="#">Sallybus</a></td>
												<td>IT</td>
												<td>+9198745632</td>
												<td>10/02/2022</td>
                                                <td><i class="icon-eye"></i></td>
												<td><i class="icon-edit"></i></td>
											</tr>
											<tr>
                                            <td>C Programming</td>
												<td>Pankaj Sharma</td>
												<td><a href="#">Sallybus</a></td>
												<td>IT</td>
												<td>+9198745632</td>
												<td>10/02/2022</td>
                                                <td><i class="icon-eye"></i></td>
												<td><i class="icon-edit"></i></td>
											</tr>
											<tr>
                                            <td>Data Structure</td>
												<td>Nabin Ghosal</td>
												<td><a href="#">Sallybus</a></td>
												<td>IT</td>
												<td>+9198745632</td>
												<td>10/02/2022</td>
                                                <td><i class="icon-eye"></i></td>
												<td><i class="icon-edit"></i></td>
                                            </tr>
										</tbody>
									</table>
								</div>
							</div>

						
								

						

						</div>
					</div>
					<!-- Row end -->

				</div>
				<!-- Main container end -->

			</div>
			<!-- Page content end -->

		</div>
		<!-- Page wrapper end -->


	</body>
</html>
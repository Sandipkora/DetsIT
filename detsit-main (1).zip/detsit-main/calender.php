<?php

include "menu.php";
include "footer.php";

?>
<!doctype html>
<html lang="en">

	</head>

	<body>
		<!-- Page wrapper start -->
			<!-- Page content start  -->
			<div class="page-content">
				
				<!-- Main container start -->
				<div class="main-container">
					<!-- Header start -->
					
					<!-- Header end -->

					<!-- Page header start -->
					<div class="page-header">
						
						<!-- Breadcrumb start -->
						<ol class="breadcrumb">
							<li class="breadcrumb-item">Google Calendar</li>
						</ol>
						<!-- Breadcrumb end -->

						<!-- App actions start -->
					</div>
					<!-- Page header end -->
					
					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							
							<div class="card m-0">
								<div class="card-body">
									<div id="calendarGoogle"></div>
								</div>
							</div>

						</div>
					</div>
					<!-- Row end -->

				</div>
				<!-- Main container end -->

			</div>
			<!-- Page content end -->

		</div>
		<!-- Page wrapper end -->


	</body>

</html>